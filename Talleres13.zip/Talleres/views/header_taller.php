<style>
    .cabeza{
    display:flex !important;
}

.icono_udg{
    position: relative;
    margin-top: -30vh;
    margin-left: 4vw;
}

.titulo_pagina{
    position: relative; 
    margin-left: -20vw;
   margin-top: -18vh;
   width: 100%;
     text-align: center;
     margin-right: 3vw;
    color: white;
    font-size:20px !important;
    z-index: 10;
    font-family: Arial, Helvetica, sans-serif;
   
}

/*responsibidad*/

@media screen and (max-width: 1000px){
    
   

    
    .icono_udg{
        margin-bottom: 7vh;
       
    }
    .titulo_pagina h1{
       margin-top: 4vh;
       margin-left: 70px;
        font-size: 60px;
    }
}

</style>


<div class="cabeza">
    <div><img class="icono_udg" src="../assets/img/udg_blanco.png" alt="../assets/img/udg_blanco.png"></div>
<div class="titulo_pagina"><h1 class="titulo">TALLERES</h1></div>
</div>